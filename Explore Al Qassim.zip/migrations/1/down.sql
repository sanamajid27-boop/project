
DROP INDEX idx_itinerary_items_attraction;
DROP INDEX idx_itinerary_items_itinerary;
DROP INDEX idx_food_category;
DROP INDEX idx_events_featured;
DROP INDEX idx_events_date;
DROP INDEX idx_attractions_featured;
DROP INDEX idx_attractions_category;
DROP TABLE itinerary_items;
DROP TABLE itineraries;
DROP TABLE food_items;
DROP TABLE events;
DROP TABLE attractions;
