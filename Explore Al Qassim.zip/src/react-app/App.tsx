import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import AttractionsPage from "@/react-app/pages/Attractions";
import EventsPage from "@/react-app/pages/Events";
import FoodCulturePage from "@/react-app/pages/FoodCulture";
import TripPlanner from "@/react-app/pages/TripPlanner";
import Map from "@/react-app/pages/Map";
import Gallery from "@/react-app/pages/Gallery";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/attractions" element={<AttractionsPage />} />
        <Route path="/events" element={<EventsPage />} />
        <Route path="/food-culture" element={<FoodCulturePage />} />
        <Route path="/trip-planner" element={<TripPlanner />} />
        <Route path="/map" element={<Map />} />
        <Route path="/gallery" element={<Gallery />} />
      </Routes>
    </Router>
  );
}
