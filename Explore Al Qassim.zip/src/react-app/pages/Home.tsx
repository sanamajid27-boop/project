import Navigation from '@/react-app/components/Navigation';
import HeroSection from '@/react-app/components/HeroSection';
import { useApi } from '@/react-app/hooks/useApi';
import { Attraction, Event } from '@/shared/types';
import AttractionCard from '@/react-app/components/AttractionCard';
import { Calendar, MapPin, Star } from 'lucide-react';

export default function Home() {
  const { data: featuredAttractions } = useApi<Attraction[]>('/api/attractions/featured');
  const { data: upcomingEvents } = useApi<Event[]>('/api/events/upcoming');

  return (
    <>
      <Navigation />
      <HeroSection />
      
      <div className="bg-gradient-to-br from-amber-50 to-orange-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          {/* Featured Attractions Section */}
          {featuredAttractions && featuredAttractions.length > 0 && (
            <section className="mb-16">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-amber-700 to-orange-700 bg-clip-text text-transparent mb-4">
                  Must-Visit Attractions
                </h2>
                <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                  Discover the crown jewels of Al Qassim - these featured destinations showcase the very best of our region
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredAttractions.slice(0, 3).map((attraction) => (
                  <AttractionCard key={attraction.id} attraction={attraction} />
                ))}
              </div>
            </section>
          )}

          {/* Upcoming Events Section */}
          {upcomingEvents && upcomingEvents.length > 0 && (
            <section className="mb-16">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-amber-700 to-orange-700 bg-clip-text text-transparent mb-4">
                  Upcoming Events
                </h2>
                <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                  Join us for exciting festivals and cultural celebrations throughout the year
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {upcomingEvents.slice(0, 3).map((event) => (
                  <div key={event.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden hover:scale-105">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-5 h-5 text-amber-600" />
                          <span className="text-amber-600 font-medium text-sm">
                            {event.event_date ? new Date(event.event_date).toLocaleDateString() : 'TBA'}
                          </span>
                        </div>
                        {event.is_featured && (
                          <div className="flex items-center space-x-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-2 py-1 rounded-full text-xs">
                            <Star className="w-3 h-3 fill-current" />
                            <span>Featured</span>
                          </div>
                        )}
                      </div>
                      
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {event.name}
                      </h3>
                      
                      {event.location && (
                        <div className="flex items-center space-x-1 text-gray-600 mb-3">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{event.location}</span>
                        </div>
                      )}
                      
                      {event.description && (
                        <p className="text-gray-600 text-sm line-clamp-3">
                          {event.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Call to Action Section */}
          <section className="text-center bg-gradient-to-r from-amber-500 to-orange-500 rounded-3xl p-12 text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to Explore Al Qassim?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Start planning your unforgettable journey through Saudi Arabia's cultural heart
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/trip-planner"
                className="bg-white text-amber-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-100 transition-colors"
              >
                Plan Your Trip
              </a>
              <a 
                href="/attractions"
                className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white hover:text-amber-600 transition-colors"
              >
                Browse Attractions
              </a>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
