import { useState, useEffect } from 'react';
import { Camera, Download, Share2, Heart, Eye, Search } from 'lucide-react';
import Navigation from '@/react-app/components/Navigation';
import { useApi } from '@/react-app/hooks/useApi';

interface Attraction {
  id: number;
  name: string;
  description: string;
  location: string;
  category: string;
  image_url: string;
  is_featured: boolean;
}

interface Event {
  id: number;
  name: string;
  description: string;
  event_date: string;
  location: string;
  image_url: string;
  category: string;
  is_featured: boolean;
}

interface FoodItem {
  id: number;
  name: string;
  description: string;
  category: string;
  image_url: string;
  cultural_significance: string;
}

type GalleryItem = {
  id: string;
  name: string;
  description: string;
  image_url: string;
  category: string;
  type: 'attraction' | 'event' | 'food';
  is_featured?: boolean;
  location?: string;
};

export default function Gallery() {
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<GalleryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [favorites, setFavorites] = useState<string[]>([]);
  const { loading, request } = useApi();

  useEffect(() => {
    loadGalleryData();
    loadFavorites();
  }, []);

  useEffect(() => {
    filterItems();
  }, [galleryItems, searchTerm, selectedCategory, selectedType]);

  const loadGalleryData = async () => {
    try {
      const [attractionsRes, eventsRes, foodRes] = await Promise.all([
        request('/api/attractions'),
        request('/api/events'),
        request('/api/food')
      ]);

      const items: GalleryItem[] = [];

      if (attractionsRes.success) {
        const attractions = attractionsRes.data.map((item: Attraction) => ({
          id: `attraction-${item.id}`,
          name: item.name,
          description: item.description,
          image_url: item.image_url,
          category: item.category,
          type: 'attraction' as const,
          is_featured: item.is_featured,
          location: item.location
        }));
        items.push(...attractions);
      }

      if (eventsRes.success) {
        const events = eventsRes.data.map((item: Event) => ({
          id: `event-${item.id}`,
          name: item.name,
          description: item.description,
          image_url: item.image_url,
          category: item.category,
          type: 'event' as const,
          is_featured: item.is_featured,
          location: item.location
        }));
        items.push(...events);
      }

      if (foodRes.success) {
        const food = foodRes.data.map((item: FoodItem) => ({
          id: `food-${item.id}`,
          name: item.name,
          description: item.description,
          image_url: item.image_url,
          category: item.category,
          type: 'food' as const
        }));
        items.push(...food);
      }

      setGalleryItems(items);
    } catch (err) {
      console.error('Failed to load gallery data:', err);
    }
  };

  const loadFavorites = () => {
    const saved = localStorage.getItem('gallery-favorites');
    if (saved) {
      setFavorites(JSON.parse(saved));
    }
  };

  const toggleFavorite = (itemId: string) => {
    const newFavorites = favorites.includes(itemId)
      ? favorites.filter(id => id !== itemId)
      : [...favorites, itemId];
    
    setFavorites(newFavorites);
    localStorage.setItem('gallery-favorites', JSON.stringify(newFavorites));
  };

  const filterItems = () => {
    let filtered = galleryItems;
    
    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.location && item.location.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item =>
        item.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter(item => item.type === selectedType);
    }
    
    setFilteredItems(filtered);
  };

  const categories = ['all', ...Array.from(new Set(galleryItems.map(item => item.category)))];
  const types = ['all', 'attraction', 'event', 'food'];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'attraction': return 'bg-blue-100 text-blue-800';
      case 'event': return 'bg-green-100 text-green-800';
      case 'food': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'attraction': return 'Attraction';
      case 'event': return 'Event';
      case 'food': return 'Food';
      default: return type;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Gallery
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore the beauty of Al Qassim through our curated collection of attractions, events, and culinary delights
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search gallery..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
              />
            </div>
            <div className="flex gap-3">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white"
              >
                <option value="all">All Types</option>
                {types.slice(1).map(type => (
                  <option key={type} value={type}>{getTypeLabel(type)}s</option>
                ))}
              </select>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-4 text-sm text-gray-600">
            <span>Showing {filteredItems.length} of {galleryItems.length} items</span>
            <span>{favorites.length} favorites</span>
          </div>
        </div>

        {/* Gallery Grid */}
        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
            {Array.from({length: 8}).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl shadow-lg overflow-hidden animate-pulse">
                <div className="w-full h-48 bg-gray-200"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-2"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-6 w-16 bg-gray-200 rounded-full"></div>
                    <div className="h-8 w-8 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && filteredItems.length === 0 && (
          <div className="text-center py-12">
            <Camera className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No items found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer group"
              onClick={() => setSelectedItem(item)}
            >
              <div className="relative overflow-hidden">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute top-3 left-3 flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(item.type)}`}>
                    {getTypeLabel(item.type)}
                  </span>
                  {item.is_featured && (
                    <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded-full text-xs font-medium">
                      Featured
                    </span>
                  )}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(item.id);
                  }}
                  className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
                >
                  <Heart className={`w-4 h-4 ${favorites.includes(item.id) ? 'text-red-500 fill-red-500' : 'text-gray-600'}`} />
                </button>
              </div>
              
              <div className="p-4">
                <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">{item.name}</h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full">
                    {item.category}
                  </span>
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <Eye className="w-3 h-3" />
                    <span>View</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {selectedItem && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setSelectedItem(null)}>
            <div className="bg-white rounded-2xl max-w-4xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="relative">
                <img
                  src={selectedItem.image_url}
                  alt={selectedItem.name}
                  className="w-full h-64 md:h-96 object-cover"
                />
                <button
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70"
                >
                  ✕
                </button>
                <div className="absolute bottom-4 left-4 flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTypeColor(selectedItem.type)}`}>
                    {getTypeLabel(selectedItem.type)}
                  </span>
                  <span className="bg-amber-500 text-white px-3 py-1 rounded-full text-sm">
                    {selectedItem.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">{selectedItem.name}</h2>
                    {selectedItem.location && (
                      <p className="text-gray-600 flex items-center">
                        <Camera className="w-4 h-4 mr-1" />
                        {selectedItem.location}
                      </p>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => toggleFavorite(selectedItem.id)}
                      className={`p-3 rounded-full transition-colors ${
                        favorites.includes(selectedItem.id)
                          ? 'bg-red-100 text-red-600'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <Heart className={favorites.includes(selectedItem.id) ? 'fill-current' : ''} size={20} />
                    </button>
                    <button className="p-3 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors">
                      <Share2 size={20} />
                    </button>
                    <button className="p-3 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors">
                      <Download size={20} />
                    </button>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed">{selectedItem.description}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
