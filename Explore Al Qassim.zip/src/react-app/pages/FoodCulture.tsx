import { useState } from 'react';
import { Search, Filter, Utensils, Leaf } from 'lucide-react';
import { useApi } from '@/react-app/hooks/useApi';
import { FoodItem } from '@/shared/types';
import Navigation from '@/react-app/components/Navigation';

export default function FoodCulturePage() {
  const { data: foodItems, loading, error } = useApi<FoodItem[]>('/api/food');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const categories = foodItems 
    ? Array.from(new Set(foodItems.map(f => f.category).filter((cat): cat is string => Boolean(cat))))
    : [];

  const filteredFoodItems = foodItems?.filter(food => {
    const matchesSearch = food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         food.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || food.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  if (loading) {
    return (
      <>
        <Navigation />
        <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="animate-pulse space-y-8">
              <div className="h-8 bg-gray-200 rounded w-1/3"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 space-y-4">
                    <div className="h-48 bg-gray-200 rounded-xl"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Navigation />
        <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-2">Error Loading Food Items</h2>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
        {/* Hero Section */}
        <div className="relative h-[400px] overflow-hidden">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: 'url(https://mocha-cdn.com/019a26a9-e66e-70f6-9e5d-2723545b8740/food-culture.jpg)'
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
          
          <div className="relative z-10 h-full flex items-center">
            <div className="max-w-7xl mx-auto px-4 w-full">
              <div className="max-w-2xl">
                <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                  Culinary Heritage of
                  <span className="block bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
                    Al Qassim
                  </span>
                </h1>
                <p className="text-xl text-gray-200 leading-relaxed">
                  Discover the rich flavors and traditions that have been passed down through generations
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Search and Filter */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 -mt-8 relative z-20">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search traditional dishes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                />
              </div>
              
              <div className="relative">
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="pl-10 pr-8 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent appearance-none bg-white min-w-[160px]"
                >
                  <option value="">All Categories</option>
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Food Items Grid */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Traditional Dishes ({filteredFoodItems.length})
            </h2>
            
            {filteredFoodItems.length === 0 ? (
              <div className="text-center py-12">
                <Utensils className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-500 mb-2">No dishes found</h3>
                <p className="text-gray-400">Try adjusting your search or filter criteria</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredFoodItems.map((food) => (
                  <div key={food.id} className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden hover:scale-105">
                    {/* Image */}
                    {food.image_url ? (
                      <div className="relative h-56 overflow-hidden">
                        <img
                          src={food.image_url}
                          alt={food.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        {food.category && (
                          <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                            {food.category}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="relative h-56 bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center">
                        <Utensils className="w-16 h-16 text-amber-300" />
                        {food.category && (
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm text-amber-700 px-3 py-1 rounded-full text-sm">
                            {food.category}
                          </div>
                        )}
                      </div>
                    )}
                    
                    {/* Content */}
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-amber-700 transition-colors">
                        {food.name}
                      </h3>
                      
                      {food.description && (
                        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                          {food.description}
                        </p>
                      )}
                      
                      {food.ingredients && (
                        <div className="mb-4 p-3 bg-amber-50 rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <Leaf className="w-4 h-4 text-amber-600" />
                            <span className="text-sm font-semibold text-amber-800">Key Ingredients</span>
                          </div>
                          <p className="text-gray-700 text-sm line-clamp-2">
                            {food.ingredients}
                          </p>
                        </div>
                      )}
                      
                      {food.cultural_significance && (
                        <div className="mb-4 p-3 bg-orange-50 rounded-lg border-l-4 border-orange-400">
                          <p className="text-gray-700 text-sm italic line-clamp-3">
                            {food.cultural_significance}
                          </p>
                        </div>
                      )}
                      
                      <button className="text-amber-600 hover:text-amber-700 font-medium text-sm hover:underline transition-colors">
                        Learn More
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Cultural Context Section */}
          <div className="mt-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-3xl p-12 text-white">
            <div className="max-w-3xl mx-auto text-center">
              <Utensils className="w-16 h-16 mx-auto mb-6 opacity-90" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                A Taste of Tradition
              </h2>
              <p className="text-lg opacity-90 leading-relaxed">
                The cuisine of Al Qassim reflects centuries of Arabian hospitality and culinary mastery. 
                Each dish tells a story of the land, the people, and the traditions that bind them together. 
                From aromatic spices to time-honored cooking methods, experience the authentic flavors that 
                have been cherished for generations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
