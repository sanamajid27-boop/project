import { useState, useEffect } from 'react';
import { MapPin, Navigation as NavIcon, Search, Filter } from 'lucide-react';
import Navigation from '@/react-app/components/Navigation';
import { useApi } from '@/react-app/hooks/useApi';

interface Attraction {
  id: number;
  name: string;
  description: string;
  location: string;
  category: string;
  image_url: string;
  latitude: number;
  longitude: number;
  is_featured: boolean;
}

export default function Map() {
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [filteredAttractions, setFilteredAttractions] = useState<Attraction[]>([]);
  const [selectedAttraction, setSelectedAttraction] = useState<Attraction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { loading, request } = useApi();

  useEffect(() => {
    loadAttractions();
  }, []);

  useEffect(() => {
    filterAttractions();
  }, [attractions, searchTerm, selectedCategory]);

  const loadAttractions = async () => {
    const response = await request('/api/attractions');
    if (response.success) {
      // Filter out attractions without coordinates
      const attractionsWithCoords = response.data.filter((attraction: Attraction) => 
        attraction.latitude && attraction.longitude
      );
      setAttractions(attractionsWithCoords);
    }
  };

  const filterAttractions = () => {
    let filtered = attractions;
    
    if (searchTerm) {
      filtered = filtered.filter(attraction =>
        attraction.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        attraction.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(attraction =>
        attraction.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }
    
    setFilteredAttractions(filtered);
  };

  const categories = ['all', ...Array.from(new Set(attractions.map(a => a.category)))];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Interactive Map
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover attractions across Al Qassim with our interactive map
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search attractions or locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Placeholder */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8 h-[600px] flex items-center justify-center">
              <div className="text-center">
                <NavIcon className="w-16 h-16 mx-auto mb-4 text-amber-500" />
                <h3 className="text-2xl font-bold text-gray-800 mb-2">Interactive Map Coming Soon</h3>
                <p className="text-gray-600 mb-6 max-w-md">
                  We're working on bringing you an interactive map experience with real-time locations 
                  and navigation features.
                </p>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-left">
                  <h4 className="font-semibold text-amber-800 mb-2">Planned Features:</h4>
                  <ul className="text-sm text-amber-700 space-y-1">
                    <li>• Interactive markers for all attractions</li>
                    <li>• GPS navigation integration</li>
                    <li>• Distance calculations</li>
                    <li>• Route planning between locations</li>
                    <li>• Offline map support</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Attractions List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6 max-h-[600px] overflow-y-auto">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <MapPin className="w-5 h-5 mr-2 text-amber-600" />
                Locations ({filteredAttractions.length})
              </h3>
              
              {loading && (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 h-16 rounded-lg"></div>
                    </div>
                  ))}
                </div>
              )}

              {!loading && filteredAttractions.length === 0 && (
                <div className="text-center text-gray-500 py-8">
                  <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No attractions found</p>
                  <p className="text-sm">Try adjusting your search or filter</p>
                </div>
              )}

              <div className="space-y-3">
                {filteredAttractions.map((attraction) => (
                  <div
                    key={attraction.id}
                    onClick={() => setSelectedAttraction(attraction)}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedAttraction?.id === attraction.id
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-gray-200 hover:border-amber-300 hover:shadow-md'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <img
                        src={attraction.image_url}
                        alt={attraction.name}
                        className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-800 truncate">
                          {attraction.name}
                        </h4>
                        <p className="text-sm text-gray-600 truncate">
                          {attraction.location}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full">
                            {attraction.category}
                          </span>
                          {attraction.is_featured && (
                            <span className="text-amber-500 text-xs font-medium">Featured</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Selected Attraction Details */}
            {selectedAttraction && (
              <div className="bg-white rounded-2xl shadow-lg p-6 mt-6">
                <h3 className="text-xl font-bold text-gray-800 mb-3">
                  {selectedAttraction.name}
                </h3>
                <img
                  src={selectedAttraction.image_url}
                  alt={selectedAttraction.name}
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
                <p className="text-gray-600 mb-3">{selectedAttraction.description}</p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-gray-500">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{selectedAttraction.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="bg-amber-100 text-amber-800 px-2 py-1 rounded-full text-xs">
                      {selectedAttraction.category}
                    </span>
                    {selectedAttraction.is_featured && (
                      <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded-full text-xs">
                        Featured
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
