import { useState, useEffect } from 'react';
import { Calendar, MapPin, Plus, Trash2, Clock, BookOpen } from 'lucide-react';
import Navigation from '@/react-app/components/Navigation';
import { useApi } from '@/react-app/hooks/useApi';

interface Attraction {
  id: number;
  name: string;
  description: string;
  location: string;
  category: string;
  image_url: string;
  is_featured: boolean;
}

interface Itinerary {
  id: number;
  name: string;
  description: string;
  duration_days: number;
  total_attractions: number;
}

interface ItineraryItem {
  id: number;
  itinerary_id: number;
  attraction_id: number;
  day_number: number;
  order_in_day: number;
  notes: string;
  attraction?: Attraction;
}

export default function TripPlanner() {
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [itineraries, setItineraries] = useState<Itinerary[]>([]);
  const [selectedItinerary, setSelectedItinerary] = useState<Itinerary | null>(null);
  const [itineraryItems, setItineraryItems] = useState<ItineraryItem[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newItinerary, setNewItinerary] = useState({ name: '', description: '', duration_days: 3 });
  const { request } = useApi();

  useEffect(() => {
    loadAttractions();
    loadItineraries();
  }, []);

  useEffect(() => {
    if (selectedItinerary) {
      loadItineraryItems(selectedItinerary.id);
    }
  }, [selectedItinerary]);

  const loadAttractions = async () => {
    const response = await request('/api/attractions');
    if (response.success) {
      setAttractions(response.data);
    }
  };

  const loadItineraries = async () => {
    const response = await request('/api/itineraries');
    if (response.success) {
      setItineraries(response.data);
    }
  };

  const loadItineraryItems = async (itineraryId: number) => {
    const response = await request(`/api/itineraries/${itineraryId}/items`);
    if (response.success) {
      setItineraryItems(response.data);
    }
  };

  const createItinerary = async (e: React.FormEvent) => {
    e.preventDefault();
    const response = await request('/api/itineraries', {
      method: 'POST',
      body: JSON.stringify(newItinerary)
    });
    
    if (response.success) {
      setItineraries([...itineraries, response.data]);
      setNewItinerary({ name: '', description: '', duration_days: 3 });
      setShowCreateForm(false);
    }
  };

  const addAttractionToItinerary = async (attractionId: number, dayNumber: number = 1) => {
    if (!selectedItinerary) return;

    const response = await request(`/api/itineraries/${selectedItinerary.id}/items`, {
      method: 'POST',
      body: JSON.stringify({
        attraction_id: attractionId,
        day_number: dayNumber,
        order_in_day: itineraryItems.filter(item => item.day_number === dayNumber).length + 1,
        notes: ''
      })
    });

    if (response.success) {
      loadItineraryItems(selectedItinerary.id);
    }
  };

  const removeFromItinerary = async (itemId: number) => {
    const response = await request(`/api/itinerary-items/${itemId}`, {
      method: 'DELETE'
    });

    if (response.success && selectedItinerary) {
      loadItineraryItems(selectedItinerary.id);
    }
  };

  const groupItemsByDay = () => {
    const grouped: { [key: number]: ItineraryItem[] } = {};
    itineraryItems.forEach(item => {
      if (!grouped[item.day_number]) {
        grouped[item.day_number] = [];
      }
      grouped[item.day_number].push(item);
    });
    
    // Sort items within each day by order_in_day
    Object.keys(grouped).forEach(day => {
      grouped[parseInt(day)].sort((a, b) => a.order_in_day - b.order_in_day);
    });
    
    return grouped;
  };

  const groupedItems = groupItemsByDay();

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Plan Your Journey
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Create personalized itineraries and discover the best of Al Qassim at your own pace
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Itineraries List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  <BookOpen className="w-5 h-5 mr-2 text-amber-600" />
                  My Itineraries
                </h2>
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 text-white p-2 rounded-lg hover:shadow-lg transition-all"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {showCreateForm && (
                <form onSubmit={createItinerary} className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <input
                    type="text"
                    placeholder="Itinerary name"
                    value={newItinerary.name}
                    onChange={(e) => setNewItinerary({...newItinerary, name: e.target.value})}
                    className="w-full mb-3 p-2 border border-gray-300 rounded-lg"
                    required
                  />
                  <textarea
                    placeholder="Description"
                    value={newItinerary.description}
                    onChange={(e) => setNewItinerary({...newItinerary, description: e.target.value})}
                    className="w-full mb-3 p-2 border border-gray-300 rounded-lg h-20"
                  />
                  <input
                    type="number"
                    placeholder="Duration (days)"
                    value={newItinerary.duration_days}
                    onChange={(e) => setNewItinerary({...newItinerary, duration_days: parseInt(e.target.value)})}
                    className="w-full mb-3 p-2 border border-gray-300 rounded-lg"
                    min="1"
                    max="30"
                    required
                  />
                  <div className="flex space-x-2">
                    <button
                      type="submit"
                      className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700"
                    >
                      Create
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowCreateForm(false)}
                      className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="space-y-3">
                {itineraries.map((itinerary) => (
                  <div
                    key={itinerary.id}
                    onClick={() => setSelectedItinerary(itinerary)}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedItinerary?.id === itinerary.id
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-gray-200 hover:border-amber-300 hover:bg-amber-25'
                    }`}
                  >
                    <h3 className="font-semibold text-gray-800 mb-1">{itinerary.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{itinerary.description}</p>
                    <div className="flex items-center text-xs text-gray-500 space-x-4">
                      <span className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {itinerary.duration_days} days
                      </span>
                      <span className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        {itinerary.total_attractions} stops
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {itineraries.length === 0 && (
                <div className="text-center text-gray-500 py-8">
                  <BookOpen className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No itineraries yet</p>
                  <p className="text-sm">Create your first trip plan!</p>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {selectedItinerary ? (
              <div className="space-y-6">
                {/* Selected Itinerary Header */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">{selectedItinerary.name}</h2>
                  <p className="text-gray-600 mb-4">{selectedItinerary.description}</p>
                  <div className="flex items-center space-x-6 text-sm text-gray-500">
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {selectedItinerary.duration_days} days
                    </span>
                    <span className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {itineraryItems.length} attractions
                    </span>
                  </div>
                </div>

                {/* Day-by-Day Itinerary */}
                {Array.from({length: selectedItinerary.duration_days}, (_, i) => i + 1).map(day => (
                  <div key={day} className="bg-white rounded-2xl shadow-lg p-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                      <Clock className="w-5 h-5 mr-2 text-amber-600" />
                      Day {day}
                    </h3>

                    {groupedItems[day] && groupedItems[day].length > 0 ? (
                      <div className="space-y-4">
                        {groupedItems[day].map((item, index) => {
                          const attraction = attractions.find(a => a.id === item.attraction_id);
                          return (
                            <div key={item.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                              <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                {index + 1}
                              </div>
                              {attraction && (
                                <>
                                  <img
                                    src={attraction.image_url}
                                    alt={attraction.name}
                                    className="w-16 h-16 rounded-lg object-cover"
                                  />
                                  <div className="flex-1">
                                    <h4 className="font-semibold text-gray-800">{attraction.name}</h4>
                                    <p className="text-sm text-gray-600">{attraction.location}</p>
                                    <span className="inline-block bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full mt-1">
                                      {attraction.category}
                                    </span>
                                  </div>
                                </>
                              )}
                              <button
                                onClick={() => removeFromItinerary(item.id)}
                                className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center text-gray-500 py-8 border-2 border-dashed border-gray-200 rounded-lg">
                        <MapPin className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                        <p>No attractions planned for Day {day}</p>
                        <p className="text-sm">Add attractions from the list below</p>
                      </div>
                    )}
                  </div>
                ))}

                {/* Available Attractions */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    Available Attractions
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {attractions.map((attraction) => (
                      <div key={attraction.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <img
                          src={attraction.image_url}
                          alt={attraction.name}
                          className="w-full h-32 object-cover rounded-lg mb-3"
                        />
                        <h4 className="font-semibold text-gray-800 mb-1">{attraction.name}</h4>
                        <p className="text-sm text-gray-600 mb-2">{attraction.location}</p>
                        <div className="flex items-center justify-between">
                          <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full">
                            {attraction.category}
                          </span>
                          <select
                            onChange={(e) => addAttractionToItinerary(attraction.id, parseInt(e.target.value))}
                            className="text-sm bg-amber-500 text-white px-3 py-1 rounded-lg hover:bg-amber-600 cursor-pointer"
                            defaultValue=""
                          >
                            <option value="" disabled>Add to day...</option>
                            {Array.from({length: selectedItinerary.duration_days}, (_, i) => i + 1).map(day => (
                              <option key={day} value={day}>Day {day}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Plan Your Adventure</h2>
                <p className="text-gray-600 mb-6">
                  Select an itinerary from the left panel or create a new one to start planning your journey through Al Qassim.
                </p>
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all"
                >
                  Create New Itinerary
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
