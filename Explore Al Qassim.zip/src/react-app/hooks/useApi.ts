import { useState, useEffect, useCallback } from 'react';

export function useApi<T>(endpoint?: string, dependencies: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!endpoint);
  const [error, setError] = useState<string | null>(null);

  const request = useCallback(async (url: string, options?: RequestInit) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
        ...options,
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      return { success: true, data: result };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!endpoint) return;
    
    const fetchData = async () => {
      const result = await request(endpoint);
      if (result.success) {
        setData(result.data);
      }
    };

    fetchData();
  }, [endpoint, request, ...dependencies]);

  const refetch = useCallback(() => {
    if (endpoint) {
      const fetchData = async () => {
        const result = await request(endpoint);
        if (result.success) {
          setData(result.data);
        }
      };
      fetchData();
    }
  }, [endpoint, request]);

  return { data, loading, error, refetch, request };
}
