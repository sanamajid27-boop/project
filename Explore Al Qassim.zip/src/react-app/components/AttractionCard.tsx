import { MapPin, Star, Plus } from 'lucide-react';
import { Attraction } from '@/shared/types';

interface AttractionCardProps {
  attraction: Attraction;
  onAddToItinerary?: (attraction: Attraction) => void;
}

export default function AttractionCard({ attraction, onAddToItinerary }: AttractionCardProps) {
  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden hover:scale-105">
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={attraction.image_url || 'https://images.unsplash.com/photo-1539650116574-75c0c6d73b6e?w=500&h=300&fit=crop'}
          alt={attraction.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        
        {attraction.is_featured ? (
          <div className="absolute top-3 left-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
            <Star className="w-3 h-3 fill-current" />
            <span>Featured</span>
          </div>
        ) : null}
        
        {attraction.category && (
          <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
            {attraction.category}
          </div>
        )}
      </div>
      
      {/* Content */}
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-amber-700 transition-colors">
          {attraction.name}
        </h3>
        
        {attraction.location && (
          <div className="flex items-center space-x-1 text-gray-600 mb-3">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{attraction.location}</span>
          </div>
        )}
        
        {attraction.description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-3">
            {attraction.description}
          </p>
        )}
        
        {/* Actions */}
        <div className="flex items-center justify-between">
          <button 
            className="text-amber-600 hover:text-amber-700 font-medium text-sm hover:underline transition-colors"
          >
            Learn More
          </button>
          
          {onAddToItinerary && (
            <button
              onClick={() => onAddToItinerary(attraction)}
              className="flex items-center space-x-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Add to Trip</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
