import { Hono } from "hono";
import { cors } from "hono/cors";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors());

// API Routes
app.get("/api/attractions", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM attractions ORDER BY is_featured DESC, name ASC").all();
  return c.json(results);
});

app.get("/api/attractions/featured", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM attractions WHERE is_featured = 1 ORDER BY name ASC").all();
  return c.json(results);
});

app.get("/api/events", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM events ORDER BY event_date ASC, is_featured DESC").all();
  return c.json(results);
});

app.get("/api/events/upcoming", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM events WHERE event_date >= date('now') ORDER BY event_date ASC LIMIT 10").all();
  return c.json(results);
});

app.get("/api/food", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM food_items ORDER BY category ASC, name ASC").all();
  return c.json(results);
});

app.get("/api/itineraries", async (c) => {
  const db = c.env.DB;
  const { results } = await db.prepare("SELECT * FROM itineraries ORDER BY created_at DESC").all();
  return c.json(results);
});

app.post("/api/itineraries", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json();
  
  const { results } = await db.prepare(
    "INSERT INTO itineraries (name, description, duration_days, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) RETURNING *"
  ).bind(body.name, body.description, body.duration_days).all();
  
  return c.json(results[0]);
});

app.get("/api/itineraries/:id/items", async (c) => {
  const db = c.env.DB;
  const itineraryId = c.req.param('id');
  
  const { results } = await db.prepare(`
    SELECT ii.*, a.name as attraction_name, a.description as attraction_description, 
           a.location, a.category, a.image_url, a.is_featured
    FROM itinerary_items ii
    LEFT JOIN attractions a ON ii.attraction_id = a.id
    WHERE ii.itinerary_id = ?
    ORDER BY ii.day_number ASC, ii.order_in_day ASC
  `).bind(itineraryId).all();
  
  return c.json(results);
});

app.post("/api/itineraries/:id/items", async (c) => {
  const db = c.env.DB;
  const itineraryId = c.req.param('id');
  const body = await c.req.json();
  
  const { results } = await db.prepare(
    "INSERT INTO itinerary_items (itinerary_id, attraction_id, day_number, order_in_day, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) RETURNING *"
  ).bind(itineraryId, body.attraction_id, body.day_number, body.order_in_day, body.notes || '').all();
  
  // Update total attractions count
  await db.prepare(
    "UPDATE itineraries SET total_attractions = (SELECT COUNT(*) FROM itinerary_items WHERE itinerary_id = ?) WHERE id = ?"
  ).bind(itineraryId, itineraryId).run();
  
  return c.json(results[0]);
});

app.delete("/api/itinerary-items/:id", async (c) => {
  const db = c.env.DB;
  const itemId = c.req.param('id');
  
  // Get itinerary ID before deleting
  const { results: itemResults } = await db.prepare("SELECT itinerary_id FROM itinerary_items WHERE id = ?").bind(itemId).all();
  if (itemResults.length === 0) {
    return c.json({ error: "Item not found" }, 404);
  }
  
  const itineraryId = itemResults[0].itinerary_id;
  
  // Delete the item
  await db.prepare("DELETE FROM itinerary_items WHERE id = ?").bind(itemId).run();
  
  // Update total attractions count
  await db.prepare(
    "UPDATE itineraries SET total_attractions = (SELECT COUNT(*) FROM itinerary_items WHERE itinerary_id = ?) WHERE id = ?"
  ).bind(itineraryId, itineraryId).run();
  
  return c.json({ success: true });
});

// Serve static files for SPA
app.get("*", async (c) => {
  return c.text("App is running", 200);
});

export default app;
