import z from "zod";

export const AttractionSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  location: z.string().nullable(),
  category: z.string().nullable(),
  image_url: z.string().nullable(),
  latitude: z.number().nullable(),
  longitude: z.number().nullable(),
  is_featured: z.number().int(), // 0 or 1
  created_at: z.string(),
  updated_at: z.string(),
});

export const EventSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  event_date: z.string().nullable(),
  start_time: z.string().nullable(),
  end_time: z.string().nullable(),
  location: z.string().nullable(),
  image_url: z.string().nullable(),
  category: z.string().nullable(),
  is_featured: z.number().int(), // 0 or 1
  created_at: z.string(),
  updated_at: z.string(),
});

export const FoodItemSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  category: z.string().nullable(),
  image_url: z.string().nullable(),
  ingredients: z.string().nullable(),
  cultural_significance: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ItinerarySchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  duration_days: z.number().nullable(),
  total_attractions: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ItineraryItemSchema = z.object({
  id: z.number(),
  itinerary_id: z.number(),
  attraction_id: z.number(),
  day_number: z.number().nullable(),
  order_in_day: z.number().nullable(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Attraction = z.infer<typeof AttractionSchema>;
export type Event = z.infer<typeof EventSchema>;
export type FoodItem = z.infer<typeof FoodItemSchema>;
export type Itinerary = z.infer<typeof ItinerarySchema>;
export type ItineraryItem = z.infer<typeof ItineraryItemSchema>;
